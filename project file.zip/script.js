// DOM Elements - Main UI
const addProblemBtn = document.getElementById('add-problem-btn');
const problemFormContainer = document.getElementById('problem-form-container');
const closeFormBtn = document.getElementById('close-form-btn');
const problemForm = document.getElementById('problem-form');
const cancelBtn = document.getElementById('cancel-btn');
const problemsContainer = document.getElementById('problems-container');
const formTitle = document.getElementById('form-title');
const progressFill = document.getElementById('progress-fill');
const progressPercentage = document.getElementById('progress-percentage');
const searchInput = document.getElementById('search-input');

// DOM Elements - Filters
const filterStatus = document.getElementById('filter-status');
const filterLanguage = document.getElementById('filter-language');
const filterTopic = document.getElementById('filter-topic');
const filterDifficulty = document.getElementById('filter-difficulty');
const sortBy = document.getElementById('sort-by');

// DOM Elements - Navigation
const navLinks = document.querySelectorAll('.sidebar-nav a');
const viewContainers = document.querySelectorAll('.view-container');

// DOM Elements - Modals

// DOM Elements - Settings
const exportDataBtn = document.getElementById('export-data-btn');
const importDataBtn = document.getElementById('import-data-btn');
const importFileInput = document.getElementById('import-file');
const resetDataBtn = document.getElementById('reset-data-btn');

// DOM Elements - Theme
const themeSwitch = document.getElementById('theme-switch');

// State
let problems = [];
let currentProblemId = null;
let problemToDelete = null;
let currentSearchTerm = '';
let currentFilters = {
    status: 'All',
    language: 'All',
    topic: 'All',
    difficulty: 'All',
    sort: 'dateDesc'
};

// Event Listeners - Core Functions
document.addEventListener('DOMContentLoaded', init);
addProblemBtn.addEventListener('click', showAddForm);
closeFormBtn.addEventListener('click', hideForm);
cancelBtn.addEventListener('click', hideForm);
problemForm.addEventListener('submit', handleFormSubmit);
//confirmDeleteBtn.addEventListener('click', confirmDelete);
cancelDeleteBtn.addEventListener('click', hideDeleteModal);
searchInput.addEventListener('input', handleSearch);

// Event Listeners - Filters
filterStatus.addEventListener('change', handleFilterChange);
filterLanguage.addEventListener('change', handleFilterChange);
filterTopic.addEventListener('change', handleFilterChange);
filterDifficulty.addEventListener('change', handleFilterChange);
sortBy.addEventListener('change', handleSortChange);

// Event Listeners - Navigation
navLinks.forEach(link => {
    link.addEventListener('click', handleNavigation);
});

// Event Listeners - Settings
exportDataBtn.addEventListener('click', exportData);
importDataBtn.addEventListener('click', () => importFileInput.click());
importFileInput.addEventListener('change', importData);



// Event Listeners - Theme
themeSwitch.addEventListener('change', toggleTheme);

// Initialize App
function init() {
    loadProblems();
    renderProblems();
    updateProgressBar();
    populateFilterOptions();
    updateStatistics();
    
    // Set theme from localStorage
    const darkMode = localStorage.getItem('darkMode') === 'true';
    themeSwitch.checked = darkMode;
    if (darkMode) {
        document.body.classList.add('dark-mode');
    }
    
    // Debug log to verify data loading
    console.log('Initial problems loaded:', problems);
}

// LocalStorage Functions
function loadProblems() {
    try {
        const storedProblems = localStorage.getItem('codingProblems');
        problems = storedProblems ? JSON.parse(storedProblems) : [];
        if (!Array.isArray(problems)) {
            throw new Error('Invalid data format in localStorage');
        }
    } catch (error) {
        console.error('Error loading problems from localStorage:', error);
        problems = [];
        showNotification('Failed to load problems. Resetting data.', 'error');
    }
}

function saveProblems() {
    try {
        localStorage.setItem('codingProblems', JSON.stringify(problems));
        console.log('Problems saved successfully:', problems);
        updateProgressBar();
        updateStatistics();
        populateFilterOptions();
    } catch (error) {
        console.error('Error saving problems to localStorage:', error);
        showNotification('Failed to save problems. Please try again.', 'error');
    }
}

// Form Functions
function showAddForm() {
    resetForm();
    formTitle.textContent = 'Add New Problem';
    problemFormContainer.classList.remove('hidden');
}

function showEditForm(id) {
    const problem = problems.find(p => p.id === id);
    if (!problem) return;
    
    resetForm();
    
    formTitle.textContent = 'Edit Problem';
    currentProblemId = id;
    
    document.getElementById('title').value = problem.title;
    document.getElementById('link').value = problem.link || '';
    document.getElementById('difficulty').value = problem.difficulty;
    document.getElementById('status').value = problem.status;
    document.getElementById('description').value = problem.description || '';
    document.getElementById('solution').value = problem.solution || '';
    document.getElementById('notes').value = problem.notes || '';
    document.getElementById('language').value = problem.language;
    document.getElementById('topic').value = problem.topic;
    document.getElementById('time-spent').value = problem.timeSpent || 0;
    document.getElementById('tags').value = problem.tags || '';
    
    problemFormContainer.classList.remove('hidden');
}

function hideForm() {
    problemFormContainer.classList.add('hidden');
    resetForm();
}

function resetForm() {
    currentProblemId = null;
    problemForm.reset();
}

function handleFormSubmit(e) {
    e.preventDefault();
    
    const formData = {
        title: document.getElementById('title').value,
        link: document.getElementById('link')?.value || '',
        difficulty: document.getElementById('difficulty').value,
        status: document.getElementById('status').value,
        description: document.getElementById('description').value,
        solution: document.getElementById('solution').value,
        notes: document.getElementById('notes').value,
        language: document.getElementById('language').value,
        topic: document.getElementById('topic').value,
        timeSpent: parseInt(document.getElementById('time-spent').value) || 0,
        tags: document.getElementById('tags').value
    };
    
    if (currentProblemId) {
        // Edit existing problem
        const index = problems.findIndex(p => p.id === currentProblemId);
        if (index !== -1) {
            problems[index] = {
                ...problems[index],
                ...formData,
                dateUpdated: new Date().toISOString()
            };
            showNotification('Problem updated successfully!', 'success');
        }
    } else {
        // Add new problem
        const newProblem = {
            id: Date.now().toString(),
            ...formData,
            dateAdded: new Date().toISOString()
        };
        
        problems.push(newProblem);
        showNotification('Problem added successfully!', 'success');
    }
    
    saveProblems();
    renderProblems();
    hideForm();
}

// Render Functions
function renderProblems() {
    problemsContainer.innerHTML = '';
    
    let filteredProblems = filterProblems(problems);
    
    if (filteredProblems.length === 0) {
        problemsContainer.innerHTML = `
            <div class="no-problems">
                <i class="fas fa-code"></i>
                <p>${currentSearchTerm || Object.values(currentFilters).some(val => val !== 'All') 
                    ? 'No problems match your filters.' 
                    : 'No problems found. Add your first coding problem!'}</p>
            </div>
        `;
        return;
    }
    
    filteredProblems.forEach(problem => {
        const card = document.createElement('div');
        card.className = `problem-card ${problem.status.toLowerCase()}`;
        
        // Convert tags from string to array if needed
        const tagsArray = problem.tags ? problem.tags.split(',').map(tag => tag.trim()).filter(tag => tag) : [];
        const tagsHtml = tagsArray.length 
            ? `<div class="problem-tags">${tagsArray.map(tag => `<span class="tag">${tag}</span>`).join('')}</div>` 
            : '';
        
        card.innerHTML = `
            <div class="problem-header">
                <h3>${problem.title}</h3>
                <span class="badge ${problem.difficulty.toLowerCase()}">${problem.difficulty}</span>
                <span class="badge ${problem.status.toLowerCase()}">${problem.status}</span>
            </div>
            <div class="problem-body">
                <div class="problem-meta">
                    <span><i class="fas fa-code"></i> ${problem.language}</span>
                    <span><i class="fas fa-tag"></i> ${problem.topic}</span>
                    ${problem.timeSpent ? `<span><i class="fas fa-clock"></i> ${problem.timeSpent} min</span>` : ''}
                </div>
                <div class="problem-description">${problem.description || ''}</div>
                ${problem.solution ? `
                    <div class="solution-toggle" data-id="${problem.id}">
                        <i class="fas fa-chevron-right"></i> Show Solution
                    </div>
                    <div class="solution-content" id="solution-${problem.id}">
                        ${problem.solution}
                    </div>
                ` : ''}
                <p class="problem-notes">${problem.notes || ''}</p>
                ${tagsHtml}
                ${problem.link ? `<a href="${problem.link}" target="_blank" class="problem-link"><i class="fas fa-external-link-alt"></i> Open Problem</a>` : ''}
            </div>
            <div class="problem-actions">
                <button class="primary-btn small-btn edit-btn" data-id="${problem.id}">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="danger-btn small-btn delete-btn" data-id="${problem.id}">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        `;
        
        problemsContainer.appendChild(card);
    });
    
    // Add event listeners
    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', () => showEditForm(btn.dataset.id));
    });
    
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', () => showDeleteModal(btn.dataset.id));
    });
    
    document.querySelectorAll('.solution-toggle').forEach(toggle => {
        toggle.addEventListener('click', function() {
            this.classList.toggle('active');
            const solutionContent = document.getElementById(`solution-${this.dataset.id}`);
            solutionContent.classList.toggle('active');
            this.innerHTML = solutionContent.classList.contains('active') 
                ? '<i class="fas fa-chevron-down"></i> Hide Solution' 
                : '<i class="fas fa-chevron-right"></i> Show Solution';
        });
    });
}

function updateProgressBar() {
    const totalProblems = problems.length;
    const solvedProblems = problems.filter(p => p.status === 'Solved').length;
    
    const percentage = totalProblems > 0 ? Math.round((solvedProblems / totalProblems) * 100) : 0;
    
    progressFill.style.width = `${percentage}%`;
    progressPercentage.textContent = `${percentage}%`;
    
    // Update statistics if on stats page
    if (!document.getElementById('stats-view').classList.contains('hidden')) {
        updateStatistics();
    }
}

// Filter and Search Functions
function filterProblems(problemsArray) {
    let result = [...problemsArray];
    
    // Apply search filter
    if (currentSearchTerm) {
        const searchLower = currentSearchTerm.toLowerCase();
        result = result.filter(problem => 
            problem.title.toLowerCase().includes(searchLower) ||
            (problem.description && problem.description.toLowerCase().includes(searchLower)) ||
            (problem.notes && problem.notes.toLowerCase().includes(searchLower)) ||
            problem.topic.toLowerCase().includes(searchLower) ||
            (problem.tags && problem.tags.toLowerCase().includes(searchLower))
        );
    }
    
    // Apply status filter
    if (currentFilters.status !== 'All') {
        result = result.filter(problem => problem.status === currentFilters.status);
    }
    
    // Apply language filter
    if (currentFilters.language !== 'All') {
        result = result.filter(problem => problem.language === currentFilters.language);
    }
    
    // Apply topic filter
    if (currentFilters.topic !== 'All') {
        result = result.filter(problem => problem.topic === currentFilters.topic);
    }
    
    // Apply difficulty filter
    if (currentFilters.difficulty !== 'All') {
        result = result.filter(problem => problem.difficulty === currentFilters.difficulty);
    }
    
    // Apply sorting
    result = sortProblems(result, currentFilters.sort);
    
    return result;
}

function sortProblems(problemsArray, sortOption) {
    const sortedProblems = [...problemsArray];
    
    switch(sortOption) {
        case 'dateDesc':
            return sortedProblems.sort((a, b) => new Date(b.dateAdded) - new Date(a.dateAdded));
        case 'dateAsc':
            return sortedProblems.sort((a, b) => new Date(a.dateAdded) - new Date(b.dateAdded));
        case 'nameAsc':
            return sortedProblems.sort((a, b) => a.title.localeCompare(b.title));
        case 'nameDesc':
            return sortedProblems.sort((a, b) => b.title.localeCompare(a.title));
        default:
            return sortedProblems;
    }
}

function handleSearch() {
    currentSearchTerm = searchInput.value.trim();
    renderProblems();
}

function handleFilterChange(e) {
    const { id, value } = e.target;
    
    switch(id) {
        case 'filter-status':
            currentFilters.status = value;
            break;
        case 'filter-language':
            currentFilters.language = value;
            break;
        case 'filter-topic':
            currentFilters.topic = value;
            break;
        case 'filter-difficulty':
            currentFilters.difficulty = value;
            break;
    }
    
    renderProblems();
}

function handleSortChange(e) {
    currentFilters.sort = e.target.value;
    renderProblems();
}

function populateFilterOptions() {
    // Get unique languages
    const languages = [...new Set(problems.map(p => p.language))];
    filterLanguage.innerHTML = '<option value="All">All</option>';
    languages.forEach(language => {
        if (language) {
            const option = document.createElement('option');
            option.value = language;
            option.textContent = language;
            filterLanguage.appendChild(option);
        }
    });
    
    // Get unique topics
    const topics = [...new Set(problems.map(p => p.topic))];
    filterTopic.innerHTML = '<option value="All">All</option>';
    topics.forEach(topic => {
        if (topic) {
            const option = document.createElement('option');
            option.value = topic;
            option.textContent = topic;
            filterTopic.appendChild(option);
        }
    });
}



// Settings Functions
function exportData() {
    try {
        const dataStr = JSON.stringify(problems, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
        
        const exportFileDefaultName = `coding_problems_${new Date().toISOString().split('T')[0]}.json`;
        
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
        
        showNotification('Data exported successfully!', 'success');
    } catch (error) {
        console.error('Error exporting data:', error);
        showNotification('Failed to export data', 'error');
    }
}

function importData(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const importedData = JSON.parse(e.target.result);
            
            if (Array.isArray(importedData)) {
                problems = importedData;
                saveProblems();
                renderProblems();
                showNotification('Data imported successfully!', 'success');
            } else {
                throw new Error('Imported data is not in the correct format');
            }
        } catch (error) {
            console.error('Error importing data:', error);
            showNotification('Failed to import data. Invalid format.', 'error');
        }
    };
    reader.readAsText(file);
    
    // Reset the file input
    e.target.value = '';
}

function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) {
        showNotification('No file selected.', 'error');
        return;
    }
    if (file.type !== 'application/json') {
        showNotification('Invalid file type. Please upload a JSON file.', 'error');
        return;
    }
    // Proceed with file processing...
}



function resetData() {
    problems = [];
    saveProblems();
    renderProblems();
    hideResetModal();
    showNotification('All data has been reset', 'warning');
}

// Navigation Functions
function handleNavigation(e) {
    e.preventDefault();
    const view = e.currentTarget.getAttribute('data-view');
    
    // Update active nav link
    navLinks.forEach(link => {
        link.parentElement.classList.remove('active');
    });
    e.currentTarget.parentElement.classList.add('active');
    
    // Show selected view and hide others
    viewContainers.forEach(container => {
        container.classList.add('hidden');
    });
    document.getElementById(`${view}-view`).classList.remove('hidden');
    
    // If switching to stats view, update statistics
    if (view === 'stats') {
        updateStatistics();
    }
}

// Statistics Functions
function updateStatistics() {
    if (!document.getElementById('stat-total-problems')) return;
    
    const totalProblems = problems.length;
    const solvedProblems = problems.filter(p => p.status === 'Solved').length;
    
    // Update stat cards
    document.getElementById('stat-total-problems').textContent = totalProblems;
    document.getElementById('stat-solved-problems').textContent = solvedProblems;
    
    // Calculate most used language
    const languageCounts = {};
    problems.forEach(problem => {
        if (problem.language) {
            languageCounts[problem.language] = (languageCounts[problem.language] || 0) + 1;
        }
    });
    
    let mostUsedLanguage = '-';
    let maxCount = 0;
    
    for (const [language, count] of Object.entries(languageCounts)) {
        if (count > maxCount) {
            mostUsedLanguage = language;
            maxCount = count;
        }
    }
    
    document.getElementById('stat-most-used-language').textContent = mostUsedLanguage;
    
    // Calculate most common topic
    const topicCounts = {};
    problems.forEach(problem => {
        if (problem.topic) {
            topicCounts[problem.topic] = (topicCounts[problem.topic] || 0) + 1;
        }
    });
    
    let mostCommonTopic = '-';
    maxCount = 0;
    
    for (const [topic, count] of Object.entries(topicCounts)) {
        if (count > maxCount) {
            mostCommonTopic = topic;
            maxCount = count;
        }
    }
    
    document.getElementById('stat-most-common-topic').textContent = mostCommonTopic;
    
    // Update charts
    updateStatusChart(solvedProblems, totalProblems - solvedProblems);
    updateDifficultyChart();
    updateLanguageDistribution();
}

function updateStatusChart(solved, unsolved) {
    const solvedSlice = document.getElementById('solved-slice');
    const unsolvedSlice = document.getElementById('unsolved-slice');
    
    const total = solved + unsolved;
    if (total === 0) {
        solvedSlice.style.transform = 'rotate(0deg)';
        unsolvedSlice.style.transform = 'rotate(0deg)';
        unsolvedSlice.style.display = 'none';
        return;
    }
    
    const solvedDegrees = (solved / total) * 360;
    
    if (solved === 0) {
        solvedSlice.style.display = 'none';
        unsolvedSlice.style.display = 'block';
        unsolvedSlice.style.transform = 'rotate(0deg)';
    } else if (unsolved === 0) {
        solvedSlice.style.display = 'block';
        unsolvedSlice.style.display = 'none';
        solvedSlice.style.transform = 'rotate(0deg)';
    } else {
        solvedSlice.style.display = 'block';
        unsolvedSlice.style.display = 'block';
        solvedSlice.style.transform = `rotate(${solvedDegrees}deg)`;
    }
}

function updateDifficultyChart() {
    const easyCount = problems.filter(p => p.difficulty === 'Easy').length;
    const mediumCount = problems.filter(p => p.difficulty === 'Medium').length;
    const hardCount = problems.filter(p => p.difficulty === 'Hard').length;
    
    const maxCount = Math.max(easyCount, mediumCount, hardCount, 1); // Avoid division by zero
    
    const easyBar = document.getElementById('easy-bar');
    const mediumBar = document.getElementById('medium-bar');
    const hardBar = document.getElementById('hard-bar');
    
    easyBar.style.height = `${(easyCount / maxCount) * 100}%`;
    mediumBar.style.height = `${(mediumCount / maxCount) * 100}%`;
    hardBar.style.height = `${(hardCount / maxCount) * 100}%`;
    
    // Add count labels
    easyBar.setAttribute('data-count', easyCount);
    mediumBar.setAttribute('data-count', mediumCount);
    hardBar.setAttribute('data-count', hardCount);
}

function updateLanguageDistribution() {
    const languageDistribution = document.getElementById('languages-distribution');
    languageDistribution.innerHTML = '';
    
    const languageCounts = {};
    problems.forEach(problem => {
        if (problem.language) {
            languageCounts[problem.language] = (languageCounts[problem.language] || 0) + 1;
        }
    });
    
    // Convert to array and sort by count
    const languageCountsArray = Object.entries(languageCounts)
        .map(([language, count]) => ({ language, count }))
        .sort((a, b) => b.count - a.count);
    
    // Take top 5 languages
    const topLanguages = languageCountsArray.slice(0, 5);
    
    const totalCount = topLanguages.reduce((sum, item) => sum + item.count, 0);
    
    topLanguages.forEach(item => {
        const percentage = totalCount > 0 ? Math.round((item.count / totalCount) * 100) : 0;
        
        const languageBar = document.createElement('div');
        languageBar.className = 'language-bar';
        languageBar.innerHTML = `
            <div class="language-name">${item.language}</div>
            <div class="language-bar-container">
                <div class="language-bar-fill" style="width: ${percentage}%"></div>
            </div>
            <div class="language-count">${item.count} (${percentage}%)</div>
        `;
        
        languageDistribution.appendChild(languageBar);
    });
    
    // If there are no languages, show a message
    if (topLanguages.length === 0) {
        languageDistribution.innerHTML = '<div class="no-data">No language data available</div>';
    }
}

// Theme Functions
function toggleTheme() {
    const darkMode = themeSwitch.checked;
    
    if (darkMode) {
        document.body.classList.add('dark-mode');
    } else {
        document.body.classList.remove('dark-mode');
    }
    
    localStorage.setItem('darkMode', darkMode);
}

// Notification Function
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <p>${message}</p>
        </div>
        <button class="close-notification">×</button>
    `;
    
    document.body.appendChild(notification);
    
    // Add close button functionality
    notification.querySelector('.close-notification').addEventListener('click', () => {
        document.body.removeChild(notification);
    });
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (document.body.contains(notification)) {
            document.body.removeChild(notification);
        }
    }, 3000);
}

// Debug Functions
const DEBUG = true;

function checkLocalStorage() {
    try {
        const storedData = localStorage.getItem('codingProblems');
        if (DEBUG) console.log('Current localStorage data:', storedData);
        return storedData;
    } catch (error) {
        console.error('Error accessing localStorage:', error);
        showNotification('Error accessing local storage. Please try again.', 'error');
        return null;
    }
}

function manualSave() {
    try {
        saveProblems();
        showNotification('Manual save attempted', 'info');
        return checkLocalStorage();
    } catch (error) {
        console.error('Error during manual save:', error);
        showNotification('Failed to save manually. Please try again.', 'error');
        return null;
    }
}

function refreshData() {
    loadProblems();
    renderProblems();
    updateProgressBar();
}

const DebugUtils = {
    checkLocalStorage,
    manualSave,
    forceRefresh: function () {
        try {
            refreshData();
            showNotification('Data refreshed successfully!', 'success');
        } catch (error) {
            console.error('Error during force refresh:', error);
            showNotification('Failed to refresh data. Please try again.', 'error');
        }
    },
};

// Expose DebugUtils globally if needed
window.DebugUtils = DebugUtils;

// Make debug functions available globally
window.checkLocalStorage = checkLocalStorage;
window.manualSave = manualSave;
window.forceRefresh = function () {
    try {
        refreshData();
        showNotification('Data refreshed successfully!', 'success');
    } catch (error) {
        console.error('Error during force refresh:', error);
        showNotification('Failed to refresh data. Please try again.', 'error');
    }
};